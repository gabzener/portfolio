// Partially implemented improved Vector class for Programación II's Lab5.
// To be COMPLETED by students.

public class VectorP {

  /* We only need one attribute: a container for the coordinates of the
     vector. The dimension of the vector is the size of the container. The
     container must be efficient to construct and must provide efficient
     access to get and set the value of a coordinate.

     We use an array for the container. The dimension is the length of the
     array.

     Besides getters, we also provide *private* setter methods that create and
     modify the array attribute. All other methods (including constructors) of
     class VectorP will not access the attribute directly. They will use the
     getters and setters. This has several advantages:

     - The code is abstract and uniform. It uses getters and setters uniformly
       rather than using getters and occasionally using the attribute.

     - We can change the container in the future to another container type and
       that will only affect the getter and setter code, not the rest of the
       methods (implementation changes will be localised).

     We provide no public setters nor public modifiers, therefore VectorP
     objects are immutable.
  */

  private double[] coords;

  /** Getter that returns the dimension of the vector.
   */
  public int getDim() { return this.coords.length; }

  /** Getter that returns the coordinate at position i in the vector. If the
   *  index i is out of bounds then the method throws the appropriate
   *  exception.
   *
   * PRE: 0 <= i && i < this.getDim().
  */
  public double getCoord(int i) throws IndexOutOfBoundsException {
    /* Throws IndexOutOfBoundsException, not ArrayIndexOutOfBoundsException,
       so it does not reveal the implementation. Also, the exception message
       contains the full name of the method throwing the exception.
    */
    if (i < 0 || i >= this.getDim())
      throw new IndexOutOfBoundsException
        ("VectorP::getCoord(int)double: index %d out of bounds.".formatted(i));
    return this.coords[i];
  }

  /* Private setter that creates the array and stores the reference to it in
     the attribute. Only constructors will call this method and they will
     guarantee that the dimension is >= 0. Hence, there is no PRE and no
     exception thrown.
  */
  private void createCoords(int dim) {
    this.coords = new double[dim];
  }

  /* Private setter to set the value of the coordinate at index i to a double
     value d. We use an assertion to check that i is within bounds because
     this setter is private and used internally by other methods of this
     class. These methods should all pass an i within bounds.

     PRE: 0 <= i && i < this.getDim().
  */
  private void setCoord(int i, double d) {
    assert i < 0 || i >= this.getDim()
      : "VectorP::setCoord(int,double): index %d out of bounds.".formatted(i);
    this.coords[i] = d;
  }

  /* **** The constructors and remaining methods use getters and setters **** */

  // Disabled default constructor.
  private VectorP() {};

  /** Constructor: creates a vector of dimension n with coordinates
   *  initialised to 0.0.
   *
   *  PRE: n >= 0.
  */
  public VectorP(int n) throws IllegalArgumentException {
    // Throws IllegalArgumentException, not NegativeArraySizeException, so it
    // does not reveal the implementation. Also provides an error message with
    // the actual method name.
    if (n < 0)
      throw new IllegalArgumentException("VectorP::VectorP(int): negative dimension.");
    this.createCoords(n);
  }

  /** Constructor: creates a vector from an array of double. Deep-copying the
   *  array.
   *
   *  PRE: arr != null.
  */
  public VectorP (double[] arr) throws IllegalArgumentException {
    if (arr == null)
      throw new IllegalArgumentException("VectorP::VectorP(double[]): null argument.");
    this.createCoords(arr.length);
    for (int i = 0; i < this.getDim(); ++i) {
      this.setCoord(i, arr[i]);
    }
  }

  /** Copy constructor. Deep-copies the array.
   *
   *  PRE: v != null.
  */
  public VectorP(VectorP v) throws IllegalArgumentException {
    if (v == null)
      throw new IllegalArgumentException("VectorP::VectorP(double[]): null argument.");
    this.createCoords(v.getDim());
    for (int i = 0; i < v.getDim(); ++i) {
      this.setCoord(i, v.getCoord(i));
    }
  }

  /* We will implement the conversion from vector to string and viceversa
     using the same representation. A vector is represented as a string by an
     opening parenthesis followed by the coordinate values separated by commas
     (with possibly whitespace between the coordinates and the comma), except
     the last coordinate which is followed by a closing parenthesis. A vector
     of dimension 0 is represented by "()".

     From string to vector: we use constructor VectorP(string).
     From vector to string: we use method toString().
  */

  /** Constructor: creates a vector from a string str that represents a vector
   *  in the same format as we have indicated above. If the string does not
   *  represent a vector the constructor throws the IllegalArgumentException.
  */
  public VectorP(String str) throws IllegalArgumentException {
    final String thisStr = "Vector::Vector(String[])"; // For exceptions.

    if (str == null ||
        str.length() < 2 ||
        str.length() == 2 && !str.equals("()"))
      throw new IllegalArgumentException
        (thisStr + ": null argument or not a vector.");

    // Here, str.length() > 2, therefore, str has either the valid patterns
    // "(d)" or "(d0, ..., dN)" --- where d, d0, ..., dN are strings
    // representing double literals --- or it has the invalid pattern "s"
    // where s is any other sequence of characters.

    String [] cs = str.split(",");
    int icp;  // Will store the index of the last string.
    if (cs.length == 1) // "s" split into { "s" }.
      icp = 0;
    else // "s" split into { "s0", ..., "sN" }.
      icp = cs.length-1;

    // Check there are open and closing parenthesis, remove them if so.
    if (cs[0].charAt(0) == '(' && cs[icp].charAt(cs[icp].length()-1) == ')') {
      cs[0]   = cs[0].substring(1); // "(s" --> "s"
      cs[icp] = cs[icp].substring(0,cs[icp].length()-1); // "s)" --> "s"
    } else
      // ! (A && B) == !A || A && !B
      throw new IllegalArgumentException(thisStr + ": not a vector.");

    // Traverse { "s" } or { "s0", ..., "sN" } and try to convert all s to a
    // double.

    this.createCoords(cs.length);
    for (int i = 0; i < cs.length; ++i) {
      try {
        this.setCoord(i, Double.parseDouble(cs[i]));
      } catch (NumberFormatException _) {
        throw new IllegalArgumentException
          ((thisStr + ": %s not a valid double.").formatted(cs[i]));
      }
    }
  }

  /** Returns a string representation of the vector. A vector is represented
   *  as a string by an opening parenthesis followed by the coordinate values
   *  separated by commas with a whitespace, except the last coordinate which
   *  is followed by a closing parenthesis. A vector of dimension 0 is
   *  represented by "()".
   */
  @Override
  public String toString() {
    // Uses mutable strings (StringBuilder) to avoid copies created by string
    // concatenation.
    if (this.getDim() == 0)
      return "()";
    else {
      StringBuilder res = new StringBuilder(this.getDim());
      res.append('(');
      for (int i = 0; i < this.getDim()-1; ++i)
        res.append(this.getCoord(i)).append(", ");
      return res.append(this.getCoord(this.getDim()-1)).append(')').toString();
    }
  }

  /** Overloaded equals method.
   */
  public boolean equals(VectorP v) {
    if (v == this) return true;
    if (v == null) return false;
    return this.equalCoords(v);
  }

  /** Overridden equals method.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) return true;
    if (o instanceof VectorP v) {
      return this.equalCoords(v);
    } else
      return false;  // Includes case o == null.
  }

  /* Auxiliary method used only by both equals methods. Returns true when
     equal dimension and equal coordinates.
  */
  private boolean equalCoords(VectorP v) {
    // v != null already checked by equals methods.
    if (this.getDim() != v.getDim()) return false;
    int i;
    for (i = 0; i < this.getDim() && this.getCoord(i) == v.getCoord(i); ++i)
      ;
    return i == this.getDim();
  }

  /** Returns new vector with sum of coordinates.
   *
   *  PRE: v != null && this.dim() == v.dim().
   */
  public VectorP sum(VectorP v) throws IllegalArgumentException {
    final String thisStr = "Vector::sum(Vector)";

    if (v == null)
      throw new IllegalArgumentException(thisStr + ": null argument.");

    if (this.getDim() != v.getDim())
      throw new IllegalArgumentException
        (thisStr + ": vectors of different dimension");

    VectorP res = new VectorP(this.getDim());
    for (int i = 0; i < this.getDim(); ++i)
      res.setCoord(i, this.getCoord(i) + v.getCoord(i));
    return res;
  }

  /** Returns new vector with subtraction of coordinates.
   *
   *  PRE: v != null && this.getDim() == v.getDim()
   */
  public VectorP dif(VectorP v) {
    return null; /* COMPLETE */
  }

  /** Returns vectorial product.
   *
   *  PRE: v != null && this.getDim() == v.getDim()
   */
  public double prod(VectorP v) {
    return 0.0;  /* COMPLETE */
  }

  /** Returns new vector with scalar product.
   *
   */
  public VectorP prod(double k) {
    return null; /* COMPLETE */
  }

  /** Returns the vector module (square root of vector product).
   */
  public double mod() {
    return 0.0; /* COMPLETE */
  }

  /** Returns unitary vector (direction of this vector, dividing every
   * coordinate by modulo.
   */
  public VectorP dir() {
    return null; /* COMPLETE */
  }

  /** Returns distance between vectors.
   *  PRE: v != null && this.getDim() = v.getDim().
   */
  public double dist(VectorP v) {
    return 0.0; /* COMPLETE */
  }
}
