class VectorTest2 {

  public static void main(String[] args) {
    double [] arr = new double [] {2.0,3.4};
    Vector v1 = new Vector(arr);
    System.out.println(v1);

    arr[0] = 1.0;
    System.out.println(v1.coord(0));

    Vector v2 = new Vector(new double[] {1.0, 2.0});
    System.out.println(v2);

    // Test copy constructor.
    // Vector v3 = new Vector(v2);
    // System.out.println(v3);

    String [] vstr = new String[] {"2", "2.0", "3.4" };
    v1 = new Vector(vstr);
    System.out.println(v1);

    Vector v4 = new Vector(vstr);
    System.out.println(v4);

    System.out.println(v1.equals(v4));


    try {
      v1 = new Vector(new String [] {"Hello", "2.0", "4.0"});
      System.out.println(v1);

    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new Vector(new String [] {"2", "2.0", "foo"});
      System.out.println(v1);

    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new Vector(new String [] {"3", "2.0", "4.5"});
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new Vector(new String [] {"3", "2.0", "4.5", "5.0", "8.0", "10"});
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }
  }
}
