class VectorPTest {

  public static void main(String[] args) {
    double [] arr = new double [] {2.0, 3.4};
    VectorP v1 = new VectorP(arr);
    System.out.println(v1);

    arr[0] = 1.0;
    System.out.println(v1.getCoord(0));

    VectorP v2 = new VectorP(new double[] {1.0, 2.0});
    System.out.println(v2);

    VectorP v3 = new VectorP(v2);
    System.out.println(v3);

    v1 = new VectorP("(2.0,3.4)");
    System.out.println(v1);

    VectorP v4 = new VectorP("(2.0, 3.4)");
    System.out.println(v4);

    v4 = new VectorP("( 2.0 , 3.4 )");
    System.out.println(v4);

    System.out.println(v1.equals(v4));


    try {
      v1 = new VectorP("(2.0,Hello)");
      System.out.println(v1);

    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("(2.0,,4.5)");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("hello");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("(1.0");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("(1.0,2.0");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("1.0, 2.0)");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }

    try {
      v1 = new VectorP("1.0)");
      System.out.println(v1);
    } catch (IllegalArgumentException e) {
      System.out.println(e.getMessage());
    }
  }
}
